#include "LevelManager.h"

LevelManager::LevelManager()
{
}

LevelManager::~LevelManager()
{
}

void LevelManager::loadLevel(int level)
{
	
}


