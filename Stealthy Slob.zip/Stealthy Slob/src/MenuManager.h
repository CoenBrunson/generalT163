#pragma once
//public:
//loadStartMenu(){}
//loadPauseMenu(){}
//update(){}
//render(){}